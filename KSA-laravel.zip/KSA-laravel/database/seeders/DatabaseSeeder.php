<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Category;
use App\Models\Post;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        

        //----------manual--------
        User::create([
            'name' => 'Zahratul jannah',
            'username' => 'zahratuljannah',
            'email' => 'zahratuljannah358901@gmail.com',
            'password' => bcrypt ('12345')
        ]);

        // User::create([
        //     'name' => 'Yolanda Aprilia',
        //     'email' => 'yolacimewew@gmail.com',
        //     'password' => bcrypt ('2345')
        // ]);

        User::factory(2)->create();


        Category::create([
            'name' => 'Program Kemanusiaan',
            'slug' => 'program-kemanusiaan',
        ]);

        Category::create([
            'name' => 'Program Keagamaan',
            'slug' => 'program-keagamaan',
        ]);

        Category::create([
            'name' => 'Program Pendidikan',
            'slug' => 'program-pendidikan',
        ]);

        Category::create([
            'name' => 'Program Asa Indonesia',
            'slug' => 'program-asa-indonesia',
        ]);

        Post::factory(5)->create();

        // Post::create([
        //     'title' => 'Judul Pertama',
        //     'category_id' => 1,
        //     'user_id'=> 1,
        //     'slug' => 'judul-pertama',
        //     'excerpt' => 'Lorem pertama, ipsum dolor sit amet consectetur adipisicing elit',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.Illo repellendus temporibus maiores, eius dolore odio omnis possimus praesentium dignissimos molestias?'
        // ]);

        // Post::create([
        //     'title' => 'Judul Kedua',
        //     'category_id' => 1,
        //     'user_id'=> 1,
        //     'slug' => 'judul-kedua',
        //     'excerpt' => 'Lorem kedua, ipsum dolor sit amet consectetur adipisicing elit',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.Illo repellendus temporibus maiores, eius dolore odio omnis possimus praesentium dignissimos molestias?'
        // ]);

        // Post::create([
        //     'title' => 'Judul ketiga',
        //     'category_id' => 2,
        //     'user_id'=> 2, 
        //     'slug' => 'judul-ketiga',
        //     'excerpt' => 'Lorem ketiga, ipsum dolor sit amet consectetur adipisicing elit',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.Illo repellendus temporibus maiores, eius dolore odio omnis possimus praesentium dignissimos molestias?'
        // ]);

        // Post::create([
        //     'title' => 'Judul keempat',
        //     'category_id' => 2,
        //     'user_id'=> 1,
        //     'slug' => 'judul-keempat',
        //     'excerpt' => 'Lorem keempat, ipsum dolor sit amet consectetur adipisicing elit',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.Illo repellendus temporibus maiores, eius dolore odio omnis possimus praesentium dignissimos molestias?'
        // ]);

        // Post::create([
        //     'title' => 'Judul kelima',
        //     'category_id' => 1,
        //     'user_id'=> 2,
        //     'slug' => 'judul-kelima',
        //     'excerpt' => 'Lorem kelima, ipsum dolor sit amet consectetur adipisicing elit',
        //     'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit.Illo repellendus temporibus maiores, eius dolore odio omnis possimus praesentium dignissimos molestias?'
        // ]);
            
            
    }
}
