@extends ('layouts.main')

@section ('container')

    <h1> Halaman About </h1>
    <img src="img/{{  $image }} " alt="{{  $name }}">
@endsection