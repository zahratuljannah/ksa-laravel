@extends ('layouts.main')

@section('container')
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.98.0">

    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/heroes/">
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="/css/heroes.css" rel="stylesheet">
  </head>
<body>
    
<main>
  <div class="px-4 py-5 my-5 text-center">
    <img class="d-block mx-auto mb-4" src="img/{{  $image }}" alt="" width="300" height="300">
    <h1 class="display-5 fw-bold">{{ $judul1 }}</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4">{{ $slogan }}</p>
        <a href="/posts" class="btn btn-primary btn-lg px-4 gap-3">Our Program</a>
    </div>
  </div>

  <div class="container px-4 py-5" id="featured-3">
    <h2 class="pb-2 border-bottom">OUR CATEGORIES</h2>
    <div class="row g-4 py-5 row-cols-1 row-cols-lg-4">
      <div class="feature col">
        <div class="feature-icon d-inline-flex align-items-center justify-content-center bg-primary bg-gradient text-white fs-2 mb-3">
          <img src="img/{{  $foto1 }}" alt="" width="100" height="100">
        </div>
        <h2>{{ $program1 }}</h2>
        <p>program yang berfokuskan di bidang kemanusiaan dalam memberikan 
          bantuan kepada masyarakat yang membutuhkan dari segi material maupun ekonomi guna 
          meningkatkan kesejahteraan hidup dalam ruang lingkup nasional dan internasional.</p>
        <a href="posts?category=program-kemanusiaan" class="icon-link d-inline-flex align-items-center">
          See more
          <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
        </a>
      </div>
      <div class="feature col">
        <div class="feature-icon d-inline-flex align-items-center justify-content-center bg-primary bg-gradient text-white fs-2 mb-3">
          <img src="img/{{  $foto2 }}" alt="" width="100" height="100">
        </div>
        <h2>{{ $program2 }}</h2>
        <p>program di bidang keagamaan dengan tujuan meningkatkan pemahaman 
          agama kepada masyarakat dan mewadahi generasi Indonesia dalam memperbaiki kualitas 
          keimanan sebagai hamba yang bertaqwa.</p>
        <a href="posts?category=program-keagamaan" class="icon-link d-inline-flex align-items-center">
          See more
          <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
        </a>
      </div>
      <div class="feature col">
        <div class="feature-icon d-inline-flex align-items-center justify-content-center bg-primary bg-gradient text-white fs-2 mb-3">
          <img src="img/{{  $foto3 }}" alt="" width="100" height="100">
        </div>
        <h2>{{ $program3 }}</h2>
        <p>program yang bergerak di bidang Pendidikan dengan tujuan memberikan 
          edukasi kepada masyarakat umum agar terhindar dari buta aksara, memfasilitasi anak-anak jalanan yang berperan sebagai pengamen, pemulung untuk tetap sekolah, dan 
          menggali serta mengembangkan potensi yang dimiliki generasi Indonesia terutama anak-anak yatim piatu, pengamen, pemulung melalui pencarian bakat.</p>
        <a href="posts?category=program-pendidikan" class="icon-link d-inline-flex align-items-center">
          See more
          <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
        </a>
      </div>
      <div class="feature col">
        <div class="feature-icon d-inline-flex align-items-center justify-content-center bg-primary bg-gradient text-white fs-2 mb-3">
          <img src="img/{{  $foto4 }}" alt="" width="100" height="100">
        </div>
        <h2>{{ $program4 }}</h2>
        <p>program yang bergerak dan difokuskan dalam aksi peduli bencana yang terjadi 
          di Indonesia. Program ini bertujuan untuk membantu masyarakat yang terdampak bencana 
          dengan cepat dan sigap.</p>
        <a href="posts?category=program-asa-indonesia" class="icon-link d-inline-flex align-items-center">
          See more
          <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
        </a>
      </div>

    </div>
  </div>

  <div class="bg-dark text-secondary mt-5 px-4 py-5 text-center">
    <div class="py-5">
      <h1 class="display-5 fw-bold text-white">Tentang Kami</h1>
      <div class="col-lg-6 mx-auto">
        <p class="fs-5 mb-4">KSA Foundation merupakan sebuah lembaga yang dibuat untuk mencapai visi menghadirkan tatanan 
          kehidupan sosial indonesia dan dunia yang berkesejahteraan dan berkemajuan secara inklusif. Nama 
          Yayasan Karya suara dan asa diambil dari tiga kata yaitu karya, suara dan asa. Defenisi kata karya 
          menurut KBBI yang berarti pekerjaan atau perbuatan, Kata suara berarti sesuatu yang disampaikan , 
          sementara kata asa itu sendiri berarti sebuah harapan dan cita-cita. Jadi dapat ditafsirkan yayasan 
          karya suara dan asa sebagai sebuah yayasan yang didirikan dengan didasari akan keinginan untuk 
          bertindak dan berbuat secara langsung dalam menyelesaikan permasalahan- permasalahan yang 
          disampaikan masyarakat demi tercapainya sebuah harapan dan cita-cita untuk menciptakan kualitas 
          hidup yang lebih baik lagi.</p>
      </div>
    </div>
  </div>
</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
@endsection
