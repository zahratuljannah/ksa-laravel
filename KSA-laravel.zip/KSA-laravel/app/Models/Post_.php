<?php

namespace App\Models;



class Post 
{
    private static $blog_posts = [
        [
            "title" => "Judul Post Pertama",
            "slug" => "judul-post-pertama",
            "author" => "Zahratul jannah",
            "body" => "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquam maiores,
            possimus distinctio aliquid voluptates explicabo reprehenderit facere in aut quod ducimus vel. 
            Est necessitatibus aperiam sequi ducimus, quibusdam voluptatibus temporibus totam labore deleniti quas, 
            laboriosam aliquid voluptatem pariatur officia? A, excepturi saepe.
            Maiores, exercitationem totam fugit est quod nesciunt numquam odio alias recusandae ratione, 
            earum cumque a asperiores, sit iste odit assumenda iusto ullam? Nisi ut optio iure officia nihil consectetur? 
            Similique facilis soluta consequuntur esse voluptate, eveniet hic explicabo."
        ],
        [
            "title" => "Judul Post Kedua",
            "slug" => "judul-post-kedua",
            "author" => "Zahratul jannah",
            "body" => "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquam maiores,
            possimus distinctio aliquid voluptates explicabo reprehenderit facere in aut quod ducimus vel. 
            Est necessitatibus aperiam sequi ducimus, quibusdam voluptatibus temporibus totam labore deleniti quas, 
            laboriosam aliquid voluptatem pariatur officia? A, excepturi saepe.
            Maiores, exercitationem totam fugit est quod nesciunt numquam odio alias recusandae ratione, 
            earum cumque a asperiores, sit iste odit assumenda iusto ullam? Nisi ut optio iure officia nihil consectetur? 
            Similique facilis soluta consequuntur esse voluptate, eveniet hic explicabo."
        ]
    ];

    public static function all(){
        return collect(self::$blog_posts);
    }

    public static function find($slug){
        $posts = static::all();

        return $posts->firstWhere('slug', $slug);
    }
}
